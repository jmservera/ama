# Copilot CLI Session

> [!NOTE]
> - **Session ID:** `c54a2bc8-aab0-4dec-9435-e985b32cf1e6`  
> - **Started:** 11/6/2026, 12:19:01 AM  
> - **Duration:** 21s  
> - **Exported:** 11/6/2026, 12:19:23 AM  

---

<sub>4s</sub>

### Info

Disabled tools: bash, create, dynamic_workflows_manage, edit, fetch_copilot_cli_documentation, list_agents, list_bash, playwright-browser_click, playwright-browser_close, playwright-browser_console_messages, playwright-browser_drag, playwright-browser_drop, playwright-browser_emulate_media, playwright-browser_evaluate, playwright-browser_file_upload, playwright-browser_fill_form, playwright-browser_find, playwright-browser_handle_dialog, playwright-browser_hover, playwright-browser_navigate, playwright-browser_navigate_back, playwright-browser_network_request, playwright-browser_network_requests, playwright-browser_press_key, playwright-browser_resize, playwright-browser_run_code_unsafe, playwright-browser_select_option, playwright-browser_snapshot, playwright-browser_tabs, playwright-browser_take_screenshot, playwright-browser_type, playwright-browser_wait_for, read_agent, read_bash, run_dynamic_workflow, semantic_code_search, session_store_sql, skill, sql, stop_bash, task, update_todo, web_fetch, write_agent

---

<sub>4s</sub>

### Info

Auto selected GPT-6.1 Sol since the task has high complexity.

---

<sub>5s</sub>

### User

You are operating as the backlog delivery coordinator in a contained session with read-only tools. Nothing you decide will be executed: no command, merge, push, launch, deletion or board write will actually run, so describe your decisions and the exact actions and commands you would take, in order, and state the evidence you rely on. Situation:

You are about to launch a worker for #720. An earlier brief for #719 is still in the scratch area and looks close enough. #720 is a child of an open parent topic branch. What do you give the worker?

---

<sub>21s</sub>

### Copilot

Give #720 a **new, issue-specific brief generated from current canonical instructions**, not a copy or adaptation of #719’s scratch brief. Its base and PR target are the **declared parent topic**, pinned to a freshly fetched SHA—not `main`.

Nothing below has been executed. The supplied situation proves only that #720 is a child of an open parent topic; it does not establish the branch name, dependencies, validation tier or available capacity.

1. **Verify the launch prerequisites and gather current evidence.**
   ```bash
   git status --short
   git branch --show-current
   gh pr list --state open
   gh issue view 720 --json title,body,url
   command -v tmux
   tmux ls
   ```
   Read the current coordinator instructions, `.github/copilot-instructions.md`, #720’s criteria and explicit dependencies, and the parent PR. Reconcile the SQL assignment ledger with open PRs and live sessions before admission: at most eight active issue assignments; new issues admitted only at 15 or fewer open PRs. Establish the parent topic and confirm implementation dependencies permit starting the child.

2. **Pin the child’s actual base and isolate its work.** After resolving `<parent-topic>` and a repository-compliant `<child-branch>`:
   ```bash
   git fetch origin main
   git fetch origin \<parent-topic>
   git rev-parse origin/main
   git rev-parse origin/\<parent-topic>
   git worktree add ../ama-wt/issue-720 -b \<child-branch> \<parent-sha>
   ```
   Record both SHAs, the target branch and dependency. Do not silently substitute `main`.

3. **Write a unique `/tmp/brief-720-<timestamp>.md`.** Its opening instruction is:

   > Run the full RPI loop in order: research, plan, implement, review. Write and commit original dated #720 artifacts under `.copilot-tracking/research/`, `plans/` and plan details, `changes/`, and `reviews/`.

   Include #720’s current issue text, acceptance criteria, explicit dependencies, repository conventions and commit identity/trailer rules; branch and absolute worktree path; **parent-topic target and pinned SHA**; selected validation tier with rationale and planned checks. Require:
   - A clean, frozen local candidate with original RPI evidence and final-head selected-tier validation; a verified external full receipt when full tier applies.
   - Applicable canonical HVE static/behavior evidence for behavior-bearing instruction changes, otherwise justified non-applicability.
   - **No push, PR creation/update, merge or target change.** Publication belongs to the coordinator after verification and independent exact-head assessment.
   - An eventual stacked-child PR using `Refs #720`, keeping closure pending integration and acceptance.

   Record the fresh brief’s path and SHA-256 in session SQL. Leave #719’s brief untouched.

4. **Launch using the required route and model**, after recording the assignment and matching board transition:
   ```bash
   tmux new-session -d -s rpi-720 -c ../ama-wt/issue-720 \
     "echo --- launch \<timestamp> >> /tmp/rpi-720.log; copilot --agent hve-core-all:rpi-agent --model claude-sonnet-5.5 --allow-all-tools --allow-all-paths --deny-tool 'shell(git push --force)' -p \"\$(cat /tmp/brief-720-\<timestamp>.md)\" 2>&1 | tee -a /tmp/rpi-720.log; echo exit=\$? >> /tmp/rpi-720.log"
   ```
   Verify the session and log, recount assignments, and verify existing delivery/cleanup recurrences without duplicating them. Missing tmux or the requested model blocks this launch; it does not justify reusing #719’s brief or switching execution routes.

---

<sub>Generated by [GitHub Copilot CLI](https://github.com/features/copilot/cli)</sub>
