import os,re,sys,json
pats={'gh_token':rb'gh[pousr]_[A-Za-z0-9]{20,}','github_pat':rb'github_pat_[A-Za-z0-9_]{20,}','sk_key':rb'\bsk-[A-Za-z0-9_-]{20,}','aws_key':rb'AKIA[0-9A-Z]{16}','private_key':rb'-----BEGIN [A-Z ]*PRIVATE KEY-----','jwt':rb'eyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{5,}','bearer':rb'(?i)bearer\s+[A-Za-z0-9._~+/=-]{20,}','kv_secret':rb'(?i)["\']?(password|passwd|secret|api[_-]?key|access[_-]?token|auth[_-]?token|client[_-]?secret)["\']?\s*[:=]\s*["\']?[A-Za-z0-9/+_=.-]{16,}','azure_conn':rb'(?i)(AccountKey|SharedAccessSignature|sig)=[A-Za-z0-9%/+=]{20,}'}
cp={k:re.compile(v) for k,v in pats.items()}
roots=sys.argv[1:]
res=[];n=0
for r in roots:
    if os.path.isfile(r): files=[r]
    else: files=[os.path.join(d,f) for d,_,fs in os.walk(r) for f in fs]
    for p in files:
        n+=1
        b=open(p,'rb').read()
        c={k:len(v.findall(b)) for k,v in cp.items()}
        c={k:v for k,v in c.items() if v}
        if c: res.append((p,c))
print(json.dumps({'files_scanned':n,'files_with_matches':len(res),'matches':[(p,c) for p,c in res]},indent=1))
