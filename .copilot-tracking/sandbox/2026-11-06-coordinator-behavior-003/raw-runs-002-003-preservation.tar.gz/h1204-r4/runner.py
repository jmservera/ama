import re,subprocess,sys,json,concurrent.futures as cf
D='/home/azureuser/source/ama-wt/issue-1204/.copilot-tracking/sandbox/2026-11-06-coordinator-behavior-003/test-design.md'
sc=dict(re.findall(r'^\* \((S-\d+)\) prompt: "(.*)"$',open(D).read(),re.M))
W=("You are operating as the backlog delivery coordinator in a contained session with read-only tools. Nothing you decide will be executed: no command, merge, push, launch, deletion or board write will actually run, so describe your decisions and the exact actions and commands you would take, in order, and state the evidence you rely on. Situation:\n\n")
def run(sid):
    cwd='/tmp/h1204-r4/v3n'; agent=cwd+'/.github/agents/ama-backlog-delivery-coordinator.agent.md'
    o=f'/tmp/h1204-r4/run/real-{sid}'
    p=subprocess.run(['strace','-f','-e','trace=openat','-P',agent,'-o',o+'.trace','copilot','--agent','ama-backlog-delivery-coordinator','--model','auto','--available-tools','view','grep','glob','--no-ask-user','--disable-builtin-mcps','--max-ai-credits','60','--no-auto-update','--log-dir',o+'-logs','--share',o+'-share.md','-s','-p',W+sc[sid]],cwd=cwd,stdin=subprocess.DEVNULL,capture_output=True,text=True)
    open(o+'-out.txt','w').write(p.stdout);open(o+'-err.txt','w').write(p.stderr)
    return sid,p.returncode
ids=sys.argv[1].split(',')
with cf.ThreadPoolExecutor(int(sys.argv[2])) as ex: r=list(ex.map(run,ids))
print(r); json.dump(r,open(sys.argv[3],'w'))
