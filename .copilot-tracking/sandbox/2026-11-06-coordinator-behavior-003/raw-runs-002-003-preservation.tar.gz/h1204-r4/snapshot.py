import os,sys,io,tarfile,gzip,hashlib,json,re,subprocess,time,shutil
REPO='/home/azureuser/source/ama-wt/issue-1204'
TS=time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())
ARCDIR=os.path.expanduser('~/.local/share/ama/tracking-archives/2026-11-06-issue1204-evidence-'+TS)
os.makedirs(ARCDIR,mode=0o700)
RESTORE='/tmp/h1204-r5-restore-'+TS
os.makedirs(RESTORE,mode=0o700)
SB=REPO+'/.copilot-tracking/sandbox/2026-11-06-coordinator-behavior-003'
SRC_COMMIT='f6b2984d9dabc181ef784caadcf045bcbb69a24a'
def sha(b): return hashlib.sha256(b).hexdigest()
def gblob(b): return hashlib.sha1(b'blob %d\0'%len(b)+b).hexdigest()
def git(*a): return subprocess.run(['git','-C',REPO]+list(a),capture_output=True,text=True,check=True).stdout

def inventory(items):
    # items: list of (abs path, member name); returns ordered list of dict; never follows symlinks
    inv=[]
    for p,name in items:
        st=os.lstat(p)
        import stat as S
        if S.S_ISLNK(st.st_mode):
            inv.append(dict(name=name,type='symlink',mode=oct(S.S_IMODE(st.st_mode)),size=0,sha256=None,link=os.readlink(p),src=p,mtime=int(st.st_mtime)))
        elif S.S_ISREG(st.st_mode):
            b=open(p,'rb').read()
            st2=os.lstat(p)
            if (st.st_size,st.st_mtime_ns)!=(st2.st_size,st2.st_mtime_ns) or len(b)!=st.st_size:
                sys.exit('REFUSE changing input '+p)
            inv.append(dict(name=name,type='regular',mode=oct(S.S_IMODE(st.st_mode)),size=len(b),sha256=sha(b),link=None,src=p,mtime=int(st.st_mtime)))
        elif S.S_ISDIR(st.st_mode):
            continue
        else:
            sys.exit('REFUSE special file '+p)
    return inv

def walk(root,prefix):
    out=[]
    for d,ds,fs in os.walk(root,followlinks=False):
        ds.sort()
        for n in sorted(fs+[x for x in ds if os.path.islink(os.path.join(d,x))]):
            p=os.path.join(d,n)
            out.append((p,prefix+os.path.relpath(p,root)))
    return out

def build(inv,out):
    fd=os.open(out,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as raw:
        gz=gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9)
        with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tf:
            for m in inv:
                ti=tarfile.TarInfo(m['name']); ti.mode=int(m['mode'],8); ti.mtime=m['mtime']; ti.uname=ti.gname=''; ti.uid=ti.gid=0
                if m['type']=='symlink':
                    ti.type=tarfile.SYMTYPE; ti.linkname=m['link']; tf.addfile(ti)
                else:
                    b=open(m['src'],'rb').read()
                    if sha(b)!=m['sha256']: sys.exit('REFUSE input changed during archive '+m['src'])
                    ti.size=len(b); tf.addfile(ti,io.BytesIO(b))
        gz.close()

def readback_restore(arch,inv,rdir):
    os.makedirs(rdir,mode=0o700)
    exp={m['name']:m for m in inv}
    seen=set(); bad=[]
    with tarfile.open(arch,'r:gz') as tf:
        for ti in tf:
            m=exp.get(ti.name)
            if m is None: bad.append(('unexpected',ti.name)); continue
            seen.add(ti.name)
            dest=os.path.join(rdir,ti.name); os.makedirs(os.path.dirname(dest),exist_ok=True)
            if ti.issym():
                if m['type']!='symlink' or ti.linkname!=m['link']: bad.append(('link',ti.name))
                os.symlink(ti.linkname,dest); continue
            b=tf.extractfile(ti).read()
            if m['type']!='regular' or sha(b)!=m['sha256'] or len(b)!=m['size'] or oct(ti.mode)!=m['mode']: bad.append(('member',ti.name))
            fd=os.open(dest,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
            with os.fdopen(fd,'wb') as f: f.write(b)
            os.chmod(dest,ti.mode)
    missing=sorted(set(exp)-seen)
    # second pass on restored tree
    for n,m in exp.items():
        dest=os.path.join(rdir,n)
        if m['type']=='regular' and (not os.path.exists(dest) or sha(open(dest,'rb').read())!=m['sha256']): bad.append(('restored-mismatch',n))
    return dict(members=len(seen),missing=missing,bad=bad,ok=(not missing and not bad and len(seen)==len(exp)))

def table(inv,extra=None):
    rows=['| member | type | mode | size | sha256 | source |','|---|---|---|---|---|---|']
    for m in inv: rows.append(f"| {m['name']} | {m['type']} | {m['mode']} | {m['size']} | {m['sha256'] or '-'} | {extra(m) if extra else m['src']} |")
    return '\n'.join(rows)

receipt={'ts':TS,'archive_dir':ARCDIR,'restore_root':RESTORE}
# A: full tracking snapshot outside the checkout
A=inventory(walk(REPO+'/.copilot-tracking','.copilot-tracking/'))
ignored=git('status','--ignored','--short','--','.copilot-tracking').strip().splitlines()
receipt['A_snapshot']=dict(members=len(A),regular=sum(m['type']=='regular' for m in A),symlinks=sum(m['type']=='symlink' for m in A),bytes=sum(m['size'] for m in A),git_status_lines=ignored)
ap=ARCDIR+'/tracking-snapshot.tar.gz'; build(A,ap)
receipt['A_snapshot'].update(path=ap,archive_sha256=sha(open(ap,'rb').read()),archive_bytes=os.path.getsize(ap))
json.dump(A,open(ARCDIR+'/tracking-snapshot.inventory.json','w'),indent=1)
receipt['A_snapshot']['readback_restore']=readback_restore(ap,A,RESTORE+'/A')
# protected: restored tracked members equal HEAD blobs
tracked=dict((l.split('\t')[1],l.split()[2]) for l in git('ls-files','-s','--','.copilot-tracking').splitlines())
prot_bad=[]
for n,blob in tracked.items():
    d=os.path.join(RESTORE,'A',n)
    if not os.path.exists(d) or gblob(open(d,'rb').read())!=blob: prot_bad.append(n)
receipt['A_snapshot']['tracked_members_vs_HEAD_blobs']=dict(checked=len(tracked),mismatch=prot_bad[:10],mismatch_count=len(prot_bad))

# C: the 68 selected transcripts (finite, from the approved manifest)
MP=SB+'/../2026-11-05-coordinator-behavior-002/raw-storage-manifest.md'
receipt['manifest_sha256']=sha(open(MP,'rb').read())
rows=re.findall(r'^\| (\.copilot-tracking/\S+) \| (\w+) \| (0o\d+) \| (\d+) \| ([0-9a-f]{64}) \| ([0-9a-f]{40}) \|',open(MP).read(),re.M)
sel=[r for r in rows if not r[0].endswith('exit-codes.json')]
bad=[]
for path,typ,mode,size,s,blob in sel:
    b=open(REPO+'/'+path,'rb').read(); hb=subprocess.run(['git','-C',REPO,'show',SRC_COMMIT+':'+path],capture_output=True).stdout
    if typ!='regular' or len(b)!=int(size) or sha(b)!=s or gblob(b)!=blob or sha(hb)!=s: bad.append(path)
receipt['C_selected']=dict(manifest_rows=len(rows),selected=len(sel),bytes=sum(int(r[3]) for r in sel),mismatch_vs_manifest_or_f6b=bad,exit_codes_row_present=any(r[0].endswith('exit-codes.json') for r in rows))
if bad or len(sel)!=68 or receipt['C_selected']['bytes']!=288862: sys.exit('selection drift '+json.dumps(receipt['C_selected']))
C=inventory([(REPO+'/'+r[0],r[0]) for r in sel])
cp=SB+'/raw-selected-68.tar.gz'; build(C,cp)
receipt['C_selected'].update(path=cp,archive_sha256=sha(open(cp,'rb').read()),archive_bytes=os.path.getsize(cp),readback_restore=readback_restore(cp,C,RESTORE+'/C'))
shutil.copyfile(cp,ARCDIR+'/raw-selected-68.tar.gz')
open(SB+'/raw-selected-68-manifest.md','w').write('<!-- markdownlint-disable-file -->\n# Lossless copy bundle manifest: the 68 selected run-001 transcripts (copy only; originals untouched)\n\n* Bundle: raw-selected-68.tar.gz (this folder), sha256 '+receipt['C_selected']['archive_sha256']+', '+str(receipt['C_selected']['archive_bytes'])+' bytes. Member names are the repo-relative original paths; members are the exact original bytes (sha256 equals the approved manifest and the blobs at source commit '+SRC_COMMIT+'). Approved selection manifest SHA256 '+receipt['manifest_sha256']+'. exit-codes.json is not in the bundle.\n* Restore: `tar -xzf raw-selected-68.tar.gz` into a new empty directory, then compare each member sha256 below. The restore proof is in storage-proof-receipt.md. Historical reports keep their old path references unchanged; those paths now resolve to the originals in git history at the source commit or to this bundle, and this is not a new validation.\n\n'+table(C,lambda m:SRC_COMMIT[:9])+'\n')

# B: new-run and run-002 external preservation (copy only)
B=inventory(walk('/tmp/h1204-r3','h1204-r3/')+walk('/tmp/h1204-r4','h1204-r4/'))
bp=SB+'/raw-runs-002-003-preservation.tar.gz'; build(B,bp)
receipt['B_runs']=dict(members=len(B),bytes=sum(m['size'] for m in B),symlinks=sum(m['type']=='symlink' for m in B),path=bp,archive_sha256=sha(open(bp,'rb').read()),archive_bytes=os.path.getsize(bp),readback_restore=readback_restore(bp,B,RESTORE+'/B'))
shutil.copyfile(bp,ARCDIR+'/raw-runs-002-003-preservation.tar.gz')
json.dump(B,open(ARCDIR+'/raw-runs.inventory.json','w'),indent=1)
open(SB+'/raw-runs-002-003-preservation-manifest.md','w').write('<!-- markdownlint-disable-file -->\n# Copy preservation manifest: external run-002 and run-003 raw files (copy only; originals untouched)\n\n* Bundle: raw-runs-002-003-preservation.tar.gz, sha256 '+receipt['B_runs']['archive_sha256']+', '+str(receipt['B_runs']['archive_bytes'])+' bytes; '+str(len(B))+' regular members, '+str(receipt['B_runs']['bytes'])+' bytes, 0 symlinks. Members: raw outputs, argv traces, exits, model share transcripts, CLI log dirs, scratch agent copies (source inputs), runner scripts, original raw mutant diffs, replay diffs and hygiene results, from /tmp/h1204-r3 (run 002) and /tmp/h1204-r4 (run 003). Credential-pattern check over these files: 0 matches (names-only check, not certification).\n* Restore: extract into a new empty directory; each member sha256 is listed below and in ARCDIR inventory.\n\n'+table(B,lambda m:m['src'])+'\n')

# protected proofs
receipt['protected']=dict(source_blob=git('hash-object','.github/agents/ama-backlog-delivery-coordinator.agent.md').strip(),refs=git('for-each-ref','--format=%(objectname) %(refname)','refs/heads/backup').strip().splitlines(),head=git('rev-parse','HEAD').strip(),tmp_h1204=dict(files=sum(len(f) for _,_,f in os.walk('/tmp/h1204')),listing_sha256=sha('\n'.join(sorted(os.path.join(d,f)+':'+str(os.path.getsize(os.path.join(d,f))) for d,_,fs in os.walk('/tmp/h1204') for f in fs)).encode())))
json.dump(receipt,open(ARCDIR+'/receipt.json','w'),indent=1)
print(json.dumps(receipt,indent=1))
